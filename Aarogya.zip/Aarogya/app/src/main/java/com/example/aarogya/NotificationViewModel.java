package com.example.aarogya;

import androidx.lifecycle.ViewModel;

public class NotificationViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}

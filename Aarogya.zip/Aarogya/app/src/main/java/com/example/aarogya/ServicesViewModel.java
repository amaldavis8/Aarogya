package com.example.aarogya;

import androidx.lifecycle.ViewModel;

public class ServicesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
